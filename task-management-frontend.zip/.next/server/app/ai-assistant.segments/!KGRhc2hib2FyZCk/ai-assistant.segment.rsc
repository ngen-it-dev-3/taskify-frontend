1:"$Sreact.fragment"
2:I[339756,["/_next/static/chunks/0js1._jsels_4.js","/_next/static/chunks/0m5mah8z1z8by.js","/_next/static/chunks/0i.l9589uvx0j.js","/_next/static/chunks/0xw6~5qocxb5y.js"],"default"]
3:I[837457,["/_next/static/chunks/0js1._jsels_4.js","/_next/static/chunks/0m5mah8z1z8by.js","/_next/static/chunks/0i.l9589uvx0j.js","/_next/static/chunks/0xw6~5qocxb5y.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"NWZql1xP-wjet9Dj0bQl7"}
