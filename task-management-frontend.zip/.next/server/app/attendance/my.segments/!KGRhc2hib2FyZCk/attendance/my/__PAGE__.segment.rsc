1:"$Sreact.fragment"
2:I[897367,["/_next/static/chunks/0js1._jsels_4.js","/_next/static/chunks/0m5mah8z1z8by.js","/_next/static/chunks/0i.l9589uvx0j.js","/_next/static/chunks/0xw6~5qocxb5y.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"children":"asdasd"}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"NWZql1xP-wjet9Dj0bQl7"}
4:null
