:HL["/_next/static/chunks/0rn43j5dzc.cd.css","style"]
:HL["/_next/static/chunks/0bu5~ra-lchnq.css","style"]
:HL["/_next/static/media/83afe278b6a6bb3c-s.p.0q-301v4kxxnr.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"(dashboard)","param":null,"prefetchHints":0,"slots":{"children":{"name":"crm","param":null,"prefetchHints":0,"slots":{"children":{"name":"sales-crm","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}}}},"staleTime":300,"buildId":"NWZql1xP-wjet9Dj0bQl7"}
